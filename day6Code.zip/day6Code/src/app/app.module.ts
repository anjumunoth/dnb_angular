import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';//inbuilt module

import { AppRoutingModule } from './app-routing.module';//custom module
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { QuantityManageComponent } from './quantity-manage/quantity-manage.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { TemplateExamplesComponent } from './template-examples/template-examples.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { EditProductPriceComponent } from './edit-product-price/edit-product-price.component';
import { CartComponent } from './cart/cart.component';
import { MainComponent } from './main/main.component';
import { PipeExamplesComponent } from './pipe-examples/pipe-examples.component';
import { DistancePipe } from './distance.pipe';
import { JsonFieldSelectorPipe } from './json-field-selector.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ProductManageComponent,
    QuantityManageComponent,
    AddToCartComponent,
    TemplateExamplesComponent,
    ParentComponent,
    ChildComponent,
    EditProductPriceComponent,
    CartComponent,
    MainComponent,
    PipeExamplesComponent,
    DistancePipe,
    JsonFieldSelectorPipe,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
