import { Pipe, PipeTransform } from '@angular/core';
import { JsonPipe } from '@angular/common';
@Pipe({
  name: 'jsonFieldSelector'
})
export class JsonFieldSelectorPipe implements PipeTransform {

  transform(pipeValue: any, arg1:string[]=[]): any {
    var jsonPipeObj=new JsonPipe();
    if(arg1.length ==0)
    {
      return JSON.stringify(pipeValue);
    }
    // only have the specified fields in the arg1;
    var newObj:Object=new Object();
    for(let i=0;i<arg1.length;i++)
    {
      console.log(arg1[i]);
      Object.defineProperty(newObj,arg1[i],{value:pipeValue[arg1[i]]});
      
    }
    console.log(newObj);
    console.log(typeof newObj)
    //return JSON.stringify({j:99});
    return (newObj);
  }

}
