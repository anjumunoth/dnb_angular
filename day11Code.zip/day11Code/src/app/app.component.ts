import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'firstProject';
  companyName="DNB";
  ctr:number=1000;
  isVisible:boolean=true;
  colours:string[]=["red","green","blue"];
  emp:any={
    empId:101,empName:"sara",salary:678789
  };
}
