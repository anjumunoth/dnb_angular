import { ImgHoverDirective } from './img-hover.directive';

describe('ImgHoverDirective', () => {
  it('should create an instance', () => {
    const directive = new ImgHoverDirective();
    expect(directive).toBeTruthy();
  });
});
