import { Component,Input, OnChanges, SimpleChanges } from '@angular/core';
import { Products } from '../Products';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnChanges {
@Input({required:true}) selectedProduct:Products|null; 
quantitySelected:number;
constructor()
{
  this.selectedProduct=null;
  this.quantitySelected=1;
}
  ngOnChanges(changes: SimpleChanges): void {
    console.log("Changes object in ngOnChange",changes);
    // check if the product changes -- IF yes, set quantitySelected to 1
    if (changes["selectedProduct"].previousValue)
    {
      if(changes["selectedProduct"].currentValue.productId != changes["selectedProduct"].previousValue.productId)
      {
        this.quantitySelected=1;
      }
    }
  }
changeQuantityEventHandler(op:string)
{
  if(op=="inc")
  {
    this.quantitySelected++;
  }
  else
  {
    this.quantitySelected--;
  }
}
confirmEventHandler()
{
  var cartObj={...this.selectedProduct,quantitySelected:this.quantitySelected};
  // emitted an event and sent the cartObj
}


}
