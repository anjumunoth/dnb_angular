import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MainComponent } from './main/main.component';
import { ProductSearchComponent } from './product-search/product-search.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { RegisterModelFormComponent } from './register-model-form/register-model-form.component';
import { Page404Component } from './page404/page404.component';

const routes: Routes = [
 
  {path:"login",component:LoginComponent},
  {path:"products",component:MainComponent},
  {path:"product-search",component:ProductSearchComponent},
  {path:"product-manage",component:ProductManageComponent},
  {
    path:"register",component:RegisterModelFormComponent
  },
  // {path:"",component:MainComponent},
  {path:"",redirectTo:"/products",pathMatch:'full'},
  {path:"**", component:Page404Component},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
