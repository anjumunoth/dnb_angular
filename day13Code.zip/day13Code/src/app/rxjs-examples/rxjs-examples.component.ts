import { Component } from '@angular/core';
import { from, Observable } from 'rxjs';

@Component({
  selector: 'app-rxjs-examples',
  templateUrl: './rxjs-examples.component.html',
  styleUrls: ['./rxjs-examples.component.css']
})
export class RxjsExamplesComponent {
  dataArr:number[];
  constructor()
  {
    this.dataArr=[];
    // data -- should it be of same type -- Not necessary
    // send data -- synchronously or async
    // create an Observable to emit the various values
    var myObservable=new Observable((subscriber)=>{
      subscriber.next(100);
      subscriber.next(200);
      subscriber.next(300);
      // subscriber.error("Demo error"); will abrutply stop here
      
      setTimeout(()=>{
        subscriber.next(400);
        subscriber.complete();// no more data is there to be sent; stream is closed
        subscriber.error("Demo error")
      
        subscriber.next(600);// ignore 600; 
      },5000);
      subscriber.next(500);
     

    });

    // open the tap ; get the water stream; subscribe to the observable
    // observer -- set of callback functions

    var mySubscription=myObservable.subscribe(
      {
        next:(value)=>{
          
          
          console.log("Subscription 1:",value);
        },
        complete:()=>{console.log("Subscription 1:data stream is over")} ,
        error:(err)=>{console.log("Subscription 1:Error",err)} 

      
    });
    // can there be multiple subscriptions: YES
    var mySubscription2=myObservable.subscribe(
      {
        next:(value:any)=>{
          console.log("Subscription 2:",value);
          this.dataArr.push(parseInt(value.toString()));
        },
        complete:()=>{console.log("Subscription 2:data stream is over")} ,
        error:(err)=>{console.log("Subscription 2:Error",err)} 

      
    });
    // Should all subsciptions handle the data in the same manner
    var mySubscription3=myObservable.subscribe(
      {
        next:(value:any)=>{console.log("Subscription 3:",(value*value));},
        complete:()=>{console.log("Subscription 3:data stream is over")} ,
        error:(err)=>{console.log("Subscription 3:Error",err)} 

      
    });
    // unsubscription
      //mySubscription.unsubscribe();// closing the tap; ngOnDestroy
    var myObservable2=from([1,2,3,4,5]);
    myObservable2.subscribe((value)=>{
      console.log("MyObservable 2 data ",value);// corresponding to the next method
    })

  }

}
