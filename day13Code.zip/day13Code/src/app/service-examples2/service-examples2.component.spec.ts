import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceExamples2Component } from './service-examples2.component';

describe('ServiceExamples2Component', () => {
  let component: ServiceExamples2Component;
  let fixture: ComponentFixture<ServiceExamples2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ServiceExamples2Component]
    });
    fixture = TestBed.createComponent(ServiceExamples2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
