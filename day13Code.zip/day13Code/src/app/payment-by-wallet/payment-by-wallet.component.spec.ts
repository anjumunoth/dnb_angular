import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByWalletComponent } from './payment-by-wallet.component';

describe('PaymentByWalletComponent', () => {
  let component: PaymentByWalletComponent;
  let fixture: ComponentFixture<PaymentByWalletComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PaymentByWalletComponent]
    });
    fixture = TestBed.createComponent(PaymentByWalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
