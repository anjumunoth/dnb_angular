import { Injectable } from '@angular/core';

@Injectable()
export class UsersManagementService {
  emailId:string;
  password:string;
  private isloggedIn:boolean;
  constructor() { 
    this.emailId="";
    this.password="";
    this.isloggedIn=false;
  }
  getLoginStatus():boolean
  {
    return this.isloggedIn;
  }
  setLoggedIn():void
  {
    this.isloggedIn=true;
  }
  setLoggedOff():void
  {
    this.isloggedIn=false;
  }
}
