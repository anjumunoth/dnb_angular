import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MainComponent } from './main/main.component';
import { ProductSearchComponent } from './product-search/product-search.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { RegisterModelFormComponent } from './register-model-form/register-model-form.component';
import { Page404Component } from './page404/page404.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByCODComponent } from './payment-by-cod/payment-by-cod.component';
import { PaymentByUpiComponent } from './payment-by-upi/payment-by-upi.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { ServiceExamplesComponent } from './service-examples/service-examples.component';
import { ServiceExamples2Component } from './service-examples2/service-examples2.component';
import { RxjsExamplesComponent } from './rxjs-examples/rxjs-examples.component';

const routes: Routes = [
  
  {path:"payments",component:PaymentsComponent,
    children:[
      {path:"paymentByNetBanking",component:PaymentByNetBankingComponent},
      {path:"paymentByWallet",component:PaymentByWalletComponent},
      {path:"paymentByCOD",component:PaymentByCODComponent},
      {path:"paymentByUpi",component:PaymentByUpiComponent},
      {path:"paymentByCard",component:PaymentByCardComponent},
    ]
  },
  {path:"rxjsExamples",component:RxjsExamplesComponent},
  {path:"productDetails",component:ProductDetailsComponent},
  {path:"serviceExamples",component:ServiceExamplesComponent},
  {path:"serviceExamples2",component:ServiceExamples2Component},
  {path:"productDetails/:pId",component:ProductDetailsComponent},
  {path:"login",component:LoginComponent},
  {path:"products",component:MainComponent},
  {path:"product-search",component:ProductSearchComponent},
  {path:"product-manage",component:ProductManageComponent},
  {
    path:"register",component:RegisterModelFormComponent
  },
  // {path:"",component:MainComponent},
  {path:"",redirectTo:"/products",pathMatch:'full'},

  {path:"**", component:Page404Component},
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{bindToComponentInputs:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
