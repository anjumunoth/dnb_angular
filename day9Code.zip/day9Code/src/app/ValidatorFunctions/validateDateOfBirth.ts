import { AbstractControl, ValidationErrors } from "@angular/forms";

export function validateDateOfBirth(startDate:Date)
{
    console.log(startDate);
    return (
        (control:AbstractControl):ValidationErrors|null=>{
            var value=new Date(control.value);
            if(!value)  
            {
                return null;
            }
            //check value > 100 years from today
            // check value <= today
            var today=new Date();
            console.log(value);
            console.log(value<=today);
            console.log(value.getFullYear()>= (today.getFullYear() -100));
            if((value<=today) && (value.getFullYear()>= (today.getFullYear() -100)))
            {
                return null;
            }
            else
            {
                return ({checkDateOfBirth:true})
            }
        }
    )
}