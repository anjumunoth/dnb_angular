import { Component } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  emailId:string;
  password:string
  startDate:Date;
  constructor()
  {
    this.emailId="";
    this.password="sara";
    this.startDate=new Date((new Date().getFullYear()-50),0,1);
  }
}
