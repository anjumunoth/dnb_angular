import { Component } from '@angular/core';
import { Products } from '../Products';

@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent {
  productsArr:Array<Products>;
  searchTerm:string;
  fieldsArr:string[];
  sortFieldName:string
  sortOrder:string;
constructor()
{
  this.sortFieldName="";
  this.sortOrder="";
  this.productsArr=[
    new Products(101,"Iphone 15 max pro",112345,12,"../assets/iphone15ProMax.jpg","Apple Iphone 15 pro max 256gb white colour"),
    new Products(102,"Google Pixel 8",11345,1,"../assets/googlePixel8.jpg","Google pixel8 512gb white colour"),
    new Products(103,"One plus 8t",56782,5,"../assets/oneplus8T.jpg","One plus 8t 16gn RAM"),
    new Products(104,"Samsung Fold",151345,7,"../assets/samsungFold.jpg","Samsung fold6 Galaxy AI"),
    new Products(105,"Vivo Y 16",12345,9,"../assets/vivoY16.jpg","Vivo Y 16 max 256gb white colour"),
  ];
  this.searchTerm="";
  this.fieldsArr=Object.keys(this.productsArr[0]);
}
serachTermKeyPressEventHandler(event:any)
{
  console.log(event.target.value);
  this.searchTerm=event.target.value;

}
sortEventHandler(sortFieldNameElement:any,sortOrderElement:any)
{
  console.log(sortFieldNameElement.options[sortFieldNameElement.selectedIndex].value);
  console.log(sortOrderElement.options[sortOrderElement.selectedIndex].value);
  this.sortOrder=sortOrderElement.options[sortOrderElement.selectedIndex].value;
  this.sortFieldName=sortFieldNameElement.options[sortFieldNameElement.selectedIndex].value;
}
changeEventHandler(ev:any)
{
  console.log("change event triggered",ev.target.selectedIndex);
}


}
