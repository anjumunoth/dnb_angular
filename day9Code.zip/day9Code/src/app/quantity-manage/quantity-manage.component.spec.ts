import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuantityManageComponent } from './quantity-manage.component';

describe('QuantityManageComponent', () => {
  let component: QuantityManageComponent;
  let fixture: ComponentFixture<QuantityManageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [QuantityManageComponent]
    });
    fixture = TestBed.createComponent(QuantityManageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
