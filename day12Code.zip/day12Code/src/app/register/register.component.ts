import { Component } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  emailIdModel:string;
  passwordModel:string
  startDate:Date;
  countries:string[];
  selectedCountry:string;
  constructor()
  {
    this.countries=["India","Sri Lanka","Australia","USA"];
    this.selectedCountry=this.countries[0];
    this.emailIdModel="sara@gmail.com";
    this.passwordModel="sara";
    this.startDate=new Date((new Date().getFullYear()-50),0,1);
  }
  submitEventHandler(formDetails:any)
  {
    console.log("Form details on submission",formDetails);
    // send these details to the api for storing to the db -- success
    //notification -- registration successful
    //redirect to login page

  }
}
