import { Component } from '@angular/core';
import { ProductsManagementService } from '../Services/products-management.service';
import { ColoursAtComponentLevelService } from '../Services/colours-at-component-level.service';

@Component({
  selector: 'app-service-examples2',
  templateUrl: './service-examples2.component.html',
  styleUrls: ['./service-examples2.component.css'],
  providers:[ColoursAtComponentLevelService]
})
export class ServiceExamples2Component {
  counter:number;
  selectedColour:string;
  constructor(private pms:ProductsManagementService, private coloursService:ColoursAtComponentLevelService)
  {
    this.counter=this.pms.ctr;
    this.selectedColour=coloursService.myColor;
  }
}
