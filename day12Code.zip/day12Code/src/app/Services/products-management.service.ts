import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductsManagementService {
  ctr:number;
  constructor() { 
    this.ctr=1;
  }
  incCtr()
  {
    this.ctr++;
  }
}
