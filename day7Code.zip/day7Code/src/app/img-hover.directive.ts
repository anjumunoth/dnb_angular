import { Directive } from '@angular/core';

@Directive({
  selector: '[appImgHover]'
})
export class ImgHoverDirective {

  constructor() { }

}
