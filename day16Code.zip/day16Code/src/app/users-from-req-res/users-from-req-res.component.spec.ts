import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsersFromReqResComponent } from './users-from-req-res.component';

describe('UsersFromReqResComponent', () => {
  let component: UsersFromReqResComponent;
  let fixture: ComponentFixture<UsersFromReqResComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UsersFromReqResComponent]
    });
    fixture = TestBed.createComponent(UsersFromReqResComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
