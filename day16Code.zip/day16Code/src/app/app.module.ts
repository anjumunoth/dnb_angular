import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';//inbuilt module

import { AppRoutingModule } from './app-routing.module';//custom module
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { QuantityManageComponent } from './quantity-manage/quantity-manage.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { TemplateExamplesComponent } from './template-examples/template-examples.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { EditProductPriceComponent } from './edit-product-price/edit-product-price.component';
import { CartComponent } from './cart/cart.component';
import { MainComponent } from './main/main.component';
import { PipeExamplesComponent } from './pipe-examples/pipe-examples.component';
import { DistancePipe } from './distance.pipe';
import { JsonFieldSelectorPipe } from './json-field-selector.pipe';
import { IndianNumberFormatPipe } from './indian-number-format.pipe';
import { ProductSearchComponent } from './product-search/product-search.component';
import { SearchArrPipe } from './search-arr.pipe';
import { SortArrPipe } from './sort-arr.pipe';
import { DirectiveExamplesComponent } from './directive-examples/directive-examples.component';
import { CustomBgColorDirective } from './custom-bg-color.directive';
import { ImgHoverDirective } from './img-hover.directive';
import { CustomToolTipDirective } from './custom-tool-tip.directive';
import { TwoWayBindingExamplesComponent } from './two-way-binding-examples/two-way-binding-examples.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { RegisterComponent } from './register/register.component';
import { CheckPasswordStrengthDirective } from './check-password-strength.directive';
import { CheckDateOfBirthDirective } from './check-date-of-birth.directive';
import { MustMatchDirective } from './must-match.directive';
import { RegisterModelFormComponent } from './register-model-form/register-model-form.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { Page404Component } from './page404/page404.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByUpiComponent } from './payment-by-upi/payment-by-upi.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { PaymentByCODComponent } from './payment-by-cod/payment-by-cod.component';
import { DemoComponent } from './Components/demo/demo.component';
import { ServiceExamplesComponent } from './service-examples/service-examples.component';
import { ServiceExamples2Component } from './service-examples2/service-examples2.component';
import { UsersManagementService } from './Services/users-management.service';
import { CartManagementService } from './Services/cart-management.service';
import { RxjsExamplesComponent } from './rxjs-examples/rxjs-examples.component';

import {HttpClientModule} from "@angular/common/http";
import { UsersFromjsonPlaceholderComponent } from './users-fromjson-placeholder/users-fromjson-placeholder.component';
import { DisplayUsersUsingObservableComponent } from './display-users-using-observable/display-users-using-observable.component';
import { UsersFromReqResComponent } from './users-from-req-res/users-from-req-res.component';
import { DebouncingExampleComponent } from './debouncing-example/debouncing-example.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ProductManageComponent,
    QuantityManageComponent,
    AddToCartComponent,
    TemplateExamplesComponent,
    ParentComponent,
    ChildComponent,
    EditProductPriceComponent,
    CartComponent,
    MainComponent,
    PipeExamplesComponent,
    DistancePipe,
    JsonFieldSelectorPipe,
    IndianNumberFormatPipe,
    ProductSearchComponent,
    SearchArrPipe,
    SortArrPipe,
    IndianNumberFormatPipe,
    DirectiveExamplesComponent,
    CustomBgColorDirective,
    ImgHoverDirective,
    CustomToolTipDirective,
    TwoWayBindingExamplesComponent,
    EditEmployeeComponent,
    RegisterComponent,
    CheckPasswordStrengthDirective,
    CheckDateOfBirthDirective,
    MustMatchDirective,
    RegisterModelFormComponent,
    LoginComponent,
    MenuComponent,
    Page404Component,
    ProductDetailsComponent,
    PaymentsComponent,
    PaymentByWalletComponent,
    PaymentByCardComponent,
    PaymentByUpiComponent,
    PaymentByNetBankingComponent,
    PaymentByCODComponent,
    DemoComponent,
    ServiceExamplesComponent,
    ServiceExamples2Component,
    RxjsExamplesComponent,
    UsersFromjsonPlaceholderComponent,
    DisplayUsersUsingObservableComponent,
    UsersFromReqResComponent,
    DebouncingExampleComponent,
  
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, 
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [UsersManagementService,CartManagementService],
  bootstrap: [AppComponent]
})
export class AppModule { }
