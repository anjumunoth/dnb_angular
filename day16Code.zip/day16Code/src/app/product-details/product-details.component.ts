import { Component,Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Products } from '../Products';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit{
  @Input() pId:number;
  productId:number;
  selectedProduct:Products | null;
  constructor(private route:ActivatedRoute,private router:Router)
  {
    console.log("Router",this.router)
    console.log("Activated Route",this.route);
    //this.productId=this.route.snapshot.params?.['pId'] || 0;
    this.pId=0;
    this.productId=this.pId;
    var navigationObj=this.router.getCurrentNavigation();
    console.log("NavigationObj",navigationObj);
    this.selectedProduct=navigationObj?.extras.state?.['selectedProduct'] || null;
  }
  ngOnInit(): void {
    // able to access the correct value of @Inputs
    this.productId=this.pId;

  }

}
