import { Directive,Input } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';
import { validateDateOfBirth } from './ValidatorFunctions/validateDateOfBirth';

@Directive({
  selector: '[checkDateOfBirth]',
  providers:[
    {provide:NG_VALIDATORS,useExisting:CheckDateOfBirthDirective,multi:true}
  ]
})
export class CheckDateOfBirthDirective implements Validator {
  @Input() checkDateOfBirth:Date;
  constructor() {
    this.checkDateOfBirth=new Date();
   }
  validate(control: AbstractControl): ValidationErrors | null {
    console.log(this.checkDateOfBirth);
    return validateDateOfBirth(this.checkDateOfBirth)(control);
  }
  
}
