import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortArr'
})
export class SortArrPipe implements PipeTransform {

  transform(arrToBeSorted: any,sortField:string,sortOrder:string): any {
    if(sortOrder =="asc")
    {
      for(let i=0;i<arrToBeSorted.length;i++)
        {
          for(let j=0;j<arrToBeSorted.length;j++)
          {
            if(arrToBeSorted[i][sortField] < arrToBeSorted[j][sortField])
            {
              var temp=arrToBeSorted[i];
              arrToBeSorted[i]=arrToBeSorted[j];
              arrToBeSorted[j]=temp;
            }
          }
        }
    }
    else
    {
      for(let i=0;i<arrToBeSorted.length;i++)
        {
          for(let j=0;j<arrToBeSorted.length;j++)
          {
            if(arrToBeSorted[i][sortField] > arrToBeSorted[j][sortField])
            {
              var temp=arrToBeSorted[i];
              arrToBeSorted[i]=arrToBeSorted[j];
              arrToBeSorted[j]=temp;
            }
          }
        }
    }
    
    return arrToBeSorted;
  }

}
