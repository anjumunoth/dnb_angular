import { Component, OnInit } from '@angular/core';
import { SearchDataService } from '../Services/search-data.service';
import { debounceTime, distinct, distinctUntilChanged, Observable, ObservableLike, Subject, switchMap } from 'rxjs';

@Component({
  selector: 'app-debouncing-example',
  templateUrl: './debouncing-example.component.html',
  styleUrls: ['./debouncing-example.component.css']
})
export class DebouncingExampleComponent implements OnInit {
  searchTerm$:Subject<string>;
  dataArr$:Observable<any>;

  constructor(private searchDataService:SearchDataService)
  {
    this.searchTerm$=new Subject<string>();
    this.dataArr$=new Observable<any>();
  }
  searchEventHandler(ev:any)
  {
   
    this.searchTerm$.next(ev.target.value);
    //this.dataArr$=this.searchDataService.searchData(this.searchTerm);
  }
  ngOnInit(): void {
    this.dataArr$=this.searchTerm$.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      switchMap((value:any)=>{
        return this.searchDataService.searchData(value);
      })
    )
  }
}
