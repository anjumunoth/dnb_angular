import { Component } from '@angular/core';
import { Products } from '../Products';
import { Router } from '@angular/router';
import { ProductsManagementService } from '../Services/products-management.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  productsArr:Array<Products>  ;
  colours:string[];
  ctr:number;
  disableIncBtn:boolean;
  showAddToCart:boolean;
  selectedProduct:Products|null;
  constructor(private router:Router,private productsManagement:ProductsManagementService)
  {
    this.selectedProduct=null;
    this.productsArr=this.productsManagement.getProductsArr();//reference
    // change the productsArr -- will affect the array in the service as well  -- YES
    this.colours=["red","green","blue","orange","violet"];
    // this.ctr=0;
    this.ctr=this.productsManagement.ctr;
    this.productsManagement.incCtr();
    this.ctr=this.productsManagement.ctr;
    
    this.disableIncBtn=true;
    this.showAddToCart=false;
  }
  addColourEventHandler(colourToBeAdded:string)
  {
    alert("Button clicked" + colourToBeAdded);
    this.colours.push(colourToBeAdded);
  }
  addToCartEventHandler(selectedProduct:Products)
  {
    this.showAddToCart=true;
    alert("Product clicked"+selectedProduct.productName);
    this.selectedProduct=selectedProduct;
  }
  detailsEventHandler(selectedProduct:Products)
  {
    // route to productDetails Component
    // load a particular path(/productDetails) in the address ;
    // html -- added an anchor element, added an attribute routerLink;
    // ts -- navigation to a particular path
    // this.router.navigate(pathasanArray,navigationOptions);
    this.router.navigate(["/productDetails",selectedProduct.productId],
      {state :{selectedProduct:selectedProduct}}
    )
    // based on address, productDetails component should be loaded -- done
  }
  confirmAddToCartEventHandler(cartObj:any)
  {
    this.showAddToCart=false;
    var pos=this.productsArr.findIndex(item => item.productId== cartObj.productId);
    if(pos >=0)
    {
      this.productsArr[pos].quantity-=cartObj.quantitySelected;
    }
  }
}
