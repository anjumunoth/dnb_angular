import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { passwordStrength } from '../ValidatorFunctions/passwordStrength';
import { passwordsMustMatch } from '../ValidatorFunctions/passwordsMustMatch';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register-model-form',
  templateUrl: './register-model-form.component.html',
  styleUrls: ['./register-model-form.component.css']
})
export class RegisterModelFormComponent {
  registerModelForm: FormGroup;
  password: FormControl;
  confirmPassword: FormControl;
  unsavedChanges:boolean;
  constructor(private formbuilder: FormBuilder,private router:Router) {
    this.unsavedChanges=true;
    this.password = new FormControl("", [Validators.required, Validators.minLength(8), passwordStrength()]);
    this.confirmPassword = new FormControl("", [Validators.required, Validators.minLength(8)]);
    // this.registerModelForm=formbuilder.group({
    //   username:new FormControl("sara",Validators.required),
    //   emailId:new FormControl("",[Validators.required,Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
    //   password:this.password,
    //   confirmPassword:this.confirmPassword,
    //   country:new FormControl("")
    // },
    // {validators: [passwordsMustMatch(['password','confirmPassword'])],
    //   updateOn:"change"
    // });
    this.registerModelForm = new FormGroup(

      {
        username: new FormControl("sara", Validators.required),
        emailId: new FormControl("", [Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
        password: this.password,
        confirmPassword: this.confirmPassword,
        country: new FormControl("")
      },
      { validators: passwordsMustMatch(['password', 'confirmPassword']) }
    );

  }
  submitEventHandler()
  {
    console.log("Form Details",this.registerModelForm.value);
    // send the data to api
    // successful registration notification
    // route to login page
    this.unsavedChanges=false;
    this.router.navigate(["/login"])
  }
}

