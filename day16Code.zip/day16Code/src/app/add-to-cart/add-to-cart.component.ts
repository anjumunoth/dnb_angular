import { Component,Input, OnChanges, SimpleChanges,Output, EventEmitter } from '@angular/core';
import { Products } from '../Products';
import { CartManagementService } from '../Services/cart-management.service';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnChanges {
@Input({required:true}) selectedProduct:Products|null; 
@Output() confirmAddToCart: EventEmitter<any>;
quantitySelected:number;
constructor(private cartService:CartManagementService)
{
  this.selectedProduct=null;
  this.quantitySelected=1;
  this.confirmAddToCart=new EventEmitter<any>();
}
  ngOnChanges(changes: SimpleChanges): void {
    console.log("Changes object in ngOnChange",changes);
    // check if the product changes -- IF yes, set quantitySelected to 1
    if (changes["selectedProduct"].previousValue)
    {
      if(changes["selectedProduct"].currentValue.productId != changes["selectedProduct"].previousValue.productId)
      {
        this.quantitySelected=1;
      }
    }
  }
changeQuantityEventHandler(op:string)
{
  if(op=="inc")
  {
    this.quantitySelected++;
  }
  else
  {
    this.quantitySelected--;
  }
}
confirmEventHandler()
{
  var cartObj={...this.selectedProduct,quantitySelected:this.quantitySelected};
  // emitted an event and sent the cartObj
  // send data to the service

  this.cartService.addItem(cartObj);
  this.confirmAddToCart.emit(cartObj);
}


}
