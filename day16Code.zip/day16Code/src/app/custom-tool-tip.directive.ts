import { Directive, ElementRef,HostListener,Input,Renderer2 } from '@angular/core';

@Directive({
  selector: '[appCustomToolTip]'
})
export class CustomToolTipDirective {
@Input() appCustomToolTip:string;
toolTip:any;
@HostListener("mouseover") onMouseOver(){
  // add the tool tip
  console.log("Inside mouse over")
  this.toolTip=this.renderer.createElement("div");
  var textElement=this.renderer.createText(this.appCustomToolTip);
  this.toolTip.appendChild(textElement);
  this.renderer.appendChild(document.body,this.toolTip);
  // position of host element
  var hostPos=this.elementRef.nativeElement.getBoundingClientRect();
  var top=hostPos.top+120+"px"
  var left=hostPos.left+20+"px";
  console.log(hostPos);
  console.log(top);
  //alert(hostPos);
  this.renderer.setStyle(this.toolTip,"top",top);
  this.renderer.setStyle(this.toolTip,"left",left);
  this.renderer.setStyle(this.toolTip,"position","absolute");
  this.renderer.setStyle(this.toolTip,"z-index",'100');
  this.renderer.setStyle(this.toolTip,"background-color",'black');
  this.renderer.setStyle(this.toolTip,"border",'3px solid white');
  this.renderer.setStyle(this.toolTip,"color",'white');



}
@HostListener("mouseout") onMouseOut(){
  // remove the tool tip
  this.renderer.removeChild(document.body,this.toolTip);
  this.toolTip="";
}
  constructor(private elementRef:ElementRef,private renderer: Renderer2) {
    this.appCustomToolTip="";
   }

}

/*
Emp obj=new Emp(101,"sara",4799);
class Emp
{ 
  public int empId;
  Emp(empId:int,empName:string,salary:int)
  {
    this.empId=empId;

  }
}
*/
