import { Directive, ElementRef,HostListener,Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appCustomBgColor]'
})
export class CustomBgColorDirective implements OnInit {
@Input() appCustomBgColor:string;
@Input() myBorder:string;
@HostListener("mouseenter") onMouseEnterEventHandler()
{
  this.elementRef.nativeElement.style.backgroundColor="aqua";
}
@HostListener("mouseleave") onMouseLeaveEventHandler()
{
  this.elementRef.nativeElement.style.backgroundColor=this.appCustomBgColor;
}
  constructor(private elementRef:ElementRef) { 
    this.elementRef.nativeElement.style.backgroundColor="violet";
    this.appCustomBgColor="";
    this.myBorder="";

  }
  ngOnInit(): void {
   if(!this.appCustomBgColor)
   {
    this.appCustomBgColor="blue";
   }
    this.elementRef.nativeElement.style.backgroundColor=this.appCustomBgColor;
   console.log(this.myBorder);
   if(!this.myBorder)
   {
    this.myBorder='none';
   }
   this.elementRef.nativeElement.style.border=this.myBorder;
  }


}
