import { Component, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UsersManagementService } from '../Services/users-management.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnDestroy {
  loginForm:FormGroup;
  emailId:FormControl;
  password:FormControl;
  unsavedChanges:boolean;
  constructor(private usersService:UsersManagementService, private router:Router,private route:ActivatedRoute)
  {
    this.unsavedChanges=true;
    this.emailId=new FormControl("",[Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]);
    this.password=new FormControl("",[Validators.required]);
    this.loginForm=new FormGroup({
      emailId:this.emailId,
      password:this.password
    });
  }
  ngOnDestroy(): void {
    alert("Loggin status : Successful")
  }
  loginEventHandler()
  {

    console.log("Form Details",this.loginForm.value);
    // send details to the api for checking in the db
    // if user is authenticated --    // navigate to the home page
    this.unsavedChanges=false;
    this.usersService.emailId=this.loginForm.value.emailId;
    this.usersService.password=this.loginForm.value.password;
    this.usersService.setLoggedIn();
    // check where I came from. If its there -- naviagate to that page; if its not there -- navigate to products page
    // check if there are any query params
    var returnUrl:any;
    this.route.queryParamMap
    .subscribe((params)=>{
      returnUrl=params.get("returnUrl");
     
      if(returnUrl)
      {
        this.router.navigate([returnUrl]);
      }
      else
      {
        this.router.navigate(["/products"])
      }
    })
    
    // if user credentials are wrong -- // display the error message and stay on the same page after resetting
  }

}
