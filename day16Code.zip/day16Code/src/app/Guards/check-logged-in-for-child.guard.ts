import { CanActivateChildFn } from '@angular/router';
import { UsersManagementService } from '../Services/users-management.service';
import { CartManagementService } from '../Services/cart-management.service';
import { inject } from '@angular/core';

export const checkLoggedInForChildGuard: CanActivateChildFn = (childRoute, state) => {
  // check if user is logged in
  // check if there are items in cart
  var usersService=inject(UsersManagementService);
  var cartsService=inject(CartManagementService);
  if(usersService.currentStatusOfLogIn && (cartsService.getCartsArr().length >0))
  {
    return true;
  }
  else
  {
    
    return false;
  }
  
};
