import { Component } from '@angular/core';

@Component({
  selector: 'app-pay-home',
  templateUrl: './pay-home.component.html',
  styleUrls: ['./pay-home.component.css']
})
export class PayHomeComponent {

}
