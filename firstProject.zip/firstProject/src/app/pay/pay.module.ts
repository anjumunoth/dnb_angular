import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PayHomeComponent } from './pay-home/pay-home.component';
import { GpayPaymentComponent } from './gpay-payment/gpay-payment.component';



@NgModule({
  exports:[PayHomeComponent],
  declarations: [
    PayHomeComponent,
    GpayPaymentComponent
  ],
  imports: [
    CommonModule
  ]
})
export class PayModule { }
