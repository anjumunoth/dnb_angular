import { Directive } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';
import { passwordStrength } from './ValidatorFunctions/passwordStrength';

@Directive({
  selector: '[checkPasswordStrength]',
  providers:[
    {provide:NG_VALIDATORS,useExisting:CheckPasswordStrengthDirective,multi:true}
  ]
})
export class CheckPasswordStrengthDirective implements Validator {

  constructor() { }
  validate(control: AbstractControl): ValidationErrors | null {
    console.log("Inside the directive validator");
    return passwordStrength()(control);
  }
  

}
