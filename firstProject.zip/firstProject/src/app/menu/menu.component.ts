import { AfterContentChecked, AfterViewChecked, Component, inject, OnDestroy,OnInit } from '@angular/core';
import { UsersManagementService } from '../Services/users-management.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit,OnDestroy
// implements AfterContentChecked,AfterViewChecked 
{
  private usersService:UsersManagementService;
  loggedInStatus:boolean;
  loggedIn:Subject<boolean>;
  constructor()
  {
    this.loggedInStatus=false;
    // available from v16 onwards; optimised way
    this.usersService=inject(UsersManagementService);
    this.loggedIn=this.usersService.isloggedIn;
    
    //this.loggedInStatus=this.usersService.getLoginStatus();
  }
  ngOnDestroy(): void {
    this.loggedIn.unsubscribe();
  }
  ngOnInit()
  {
    this.loggedIn.subscribe((value)=>{
      this.loggedInStatus=value;
    })
  }
  // get the latest values from the services again
  // Why lifecycle method -- perform implicit activity based on changes
  // menu has to be notified whenever loggin status changes
  // ngOnInit -- no ; after constructor
  // ngOnDestroy -- used for cleaning up
  // ngOnChanges -- no ; useful for accessing the data from parent; @Input
  // 4 more lifecycle methods 
  // ngAfterContentInit and ngAfterViewInit -- will be called once during the entire lifecycle
  // ngAfterContentChecked and ngAfterViewChecked -- will be called multiple times
  // change detection 
  // after look out for model changes -- ngAfterContentChecked is called for each change in any component; (if model has not changed, still this method is invoked)
  // after look out for view changes -- ngAfterContentChecked is called for each change in any component; (if complete view has not changed, still this method is invoked)
  // Is working with ngAfterContentChecked and ngAfterContentChecked -- Very heavy; Use with caution

  // ngAfterContentChecked(): void {
  //   console.log("After content checked");
  //   this.loggedInStatus=this.usersService.getLoginStatus();// Not an optimised solution
  // }
  // ngAfterViewChecked(): void {
  //   console.log("After view checked")
  // }
  logoutEventHandler()
  {
    console.log("User logged out");
    this.usersService.setLoggedOff();
    this.usersService.emailId="";
    this.usersService.password="";


  }
}
