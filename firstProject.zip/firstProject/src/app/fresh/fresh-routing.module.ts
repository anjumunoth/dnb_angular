import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FreshComponent } from './fresh.component';
import { GroceriesComponent } from './groceries/groceries.component';
import { FruitsComponent } from './fruits/fruits.component';
import { VegetablesComponent } from './vegetables/vegetables.component';

const routes: Routes = [
  {path:"groceries",component:GroceriesComponent},// fresh/groceries
  {path:"fruits",component:FruitsComponent},
  {path:"vegetables",component:VegetablesComponent},
  { path: '', component: FreshComponent },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FreshRoutingModule { }
