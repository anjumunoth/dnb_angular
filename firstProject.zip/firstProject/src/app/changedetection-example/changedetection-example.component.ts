import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'app-changedetection-example',
  templateUrl: './changedetection-example.component.html',
  styleUrls: ['./changedetection-example.component.css'],
  
})
export class ChangedetectionExampleComponent {
  companyName:string;
  courseName:string;
  counter:any;
  num1:number;
  constructor()
  {
    this.companyName="dnb";
    this.courseName="angular";
    this.counter={ctr:1};
    this.num1=0;
  }
  changeCompanyNameEventHandler()
  {
    this.companyName="dan and bradstreet";
  }
  incEventHandler()
  {
    this.counter.ctr=this.counter.ctr+1;// changing the property
    // this.counter={
    //   ctr:this.counter.ctr +1
    // };// changing the reference
  }
  incNum1EventHandler()
  {
    this.num1++;
  }
}
