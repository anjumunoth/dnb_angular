import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchArr'
})
export class SearchArrPipe implements PipeTransform {

  transform(value: any,searchTerm:string,searchFieldArr:string[]): any {
    if(!searchTerm || searchTerm== "")
    {
      return value;
    }
    if(searchFieldArr.length<=0)
    {
      return value;
    }
    
    var filteredArr=value;;
    
    var pattern=new RegExp(searchTerm,"i");
    //filter out the elements in the array based on search tern
    var filteredArr=value.filter((item:any )=>{
      for(let i=0;i<searchFieldArr.length;i++)
      {
        // if((item[searchFieldArr[i]]).toLowerCase().includes(searchTerm.toLowerCase()))
        if((pattern.test(item[searchFieldArr[i]])))
        {
          return true;
        }
        
      }
      return false;
      
    })


    return filteredArr;
  }

}
