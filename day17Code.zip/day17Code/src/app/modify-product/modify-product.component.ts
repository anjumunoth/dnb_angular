import { Component, OnInit } from '@angular/core';
import { Products } from '../Products';
import { ProductsNgrxApiService } from '../products-ngrx-api.service';
import { Store } from '@ngrx/store';
import { ProductsActions, ProductsApiActions } from 'src/Store/Actions/products.actions';
import { productsManageSelector } from 'src/Store/Selectors/products.selector';

@Component({
  selector: 'app-modify-product',
  templateUrl: './modify-product.component.html',
  styleUrls: ['./modify-product.component.css']
})
export class ModifyProductComponent implements OnInit {
  productsArr: Array<Products>;
  showAddProduct: boolean;
  showEditProduct:boolean;
  productToBeEdited:Products|null;
  constructor(private productsNgrxApi: ProductsNgrxApiService, private store: Store) {
    this.productsArr = [];
    this.showAddProduct = false;
    this.showEditProduct=false;
    this.productToBeEdited=null;
  }
  ngOnInit() {
    // get the productsArr from the store;
    // when will I dispatch an action --  for transition on state;
    // dispatch any action -- NO 
    // Selectors -- use the selectors and get the slice of data which i require
    // selector -- return an observable of data;
    this.store.select(productsManageSelector)
      .subscribe((data) => {
        console.log("data from the store", data);
        this.productsArr = data;
      })



  }
  addProductEventHandler() {
    this.showAddProduct = true;
  }
  deleteEventHandler(pId: number) {
    // delete a element 
    // dispatch an action
    //
    this.store.dispatch(ProductsActions.deleteProduct({ productId: pId }));
  }
  editEventHandler(productToBeEdited: Products) {
    this.showEditProduct=true;
    this.productToBeEdited=productToBeEdited;
  }
}
