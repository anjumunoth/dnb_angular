import { Component, OnInit } from '@angular/core';
import { Products } from './Products';
import { ProductsNgrxApiService } from './products-ngrx-api.service';
import { ProductsApiActions } from 'src/Store/Actions/products.actions';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  productsArr: Array<Products>;
  constructor(private productsNgrxApi: ProductsNgrxApiService, private store: Store) {
    this.productsArr = [];

  }
  ngOnInit() {
    this.productsNgrxApi.getAllProducts()
      .subscribe((data) => {
        console.log("Response from the get request", data);
        //this.productsArr=data;
        // dispatch an action : store the data from api in the store
        // dispatch -- inject the Store
        this.store.dispatch(ProductsApiActions.storeProductsList({ productsArr: data }));

      });


  }
}
