import { TestBed } from '@angular/core/testing';

import { ProductsNgrxApiService } from './products-ngrx-api.service';

describe('ProductsNgrxApiService', () => {
  let service: ProductsNgrxApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProductsNgrxApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
