import { Component } from '@angular/core';
import { Products } from '../Products';
import { Store } from '@ngrx/store';
import { ProductsActions } from 'src/Store/Actions/products.actions';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {
  constructor(private store:Store)
  {

  }
  saveEventHandler(productName:string,price:string,quantity:string)
  {
    var productId:number=Math.round((Math.random()*100));
    var newProduct:Products=new Products(productId,productName,parseInt(price),parseInt(quantity),"","")
    //dispatch an action to add this new product
    this.store.dispatch(ProductsActions.addProduct({newProduct:newProduct}));
    
  }
}
