import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from "@angular/common/http"

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ModifyProductComponent } from './modify-product/modify-product.component';
import { StoreModule } from '@ngrx/store';
import {productsChangeReducer} from "../Store/Reducers/productsChange.reducer"
import { AddProductComponent } from './add-product/add-product.component';
import { EditProductComponent } from './edit-product/edit-product.component';

@NgModule({
  declarations: [
    AppComponent,
    ModifyProductComponent,
    AddProductComponent,
    EditProductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    StoreModule.forRoot(
      {
        "productsManage":productsChangeReducer,
        
       
      })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
