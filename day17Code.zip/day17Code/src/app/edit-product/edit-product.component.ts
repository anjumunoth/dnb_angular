import { Component,Input } from '@angular/core';
import { Products } from '../Products';
import { ProductsActions } from 'src/Store/Actions/products.actions';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent {
@Input() productToBeEdited:Products|null;
constructor(private store:Store)
{
  this.productToBeEdited=null;
}
saveEventHandler(productName:string,price:string,quantity:string)
  {
    if(this.productToBeEdited)
    {
      var editedProduct:Products={...this.productToBeEdited,price:parseInt(price),quantity:parseInt(quantity),productName:productName}
    //dispatch an action to edit the product
    this.store.dispatch(ProductsActions.editProduct({productToBeEdited:editedProduct}));
    }
  }
}
