import { Products } from "src/app/Products";
import {createActionGroup, props} from "@ngrx/store"
export var ProductsActions=createActionGroup({
    source:"ProductsChange",
    events:{
        "Add Product":props<{newProduct:Products}>(),
        "Edit Product":props<{productToBeEdited:Products}>(),
        "Delete Product":props<{productId:number}>()
    }
})

export var ProductsApiActions=createActionGroup({
    source:"ProductsFromApi",
    events:{
        "Store Products List":props<{productsArr:Array<Products>}>(),
    }
})