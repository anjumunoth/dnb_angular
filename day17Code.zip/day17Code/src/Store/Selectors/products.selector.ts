import { createFeatureSelector, createSelector } from "@ngrx/store";
import { Products } from "src/app/Products";

// featureName:productsManage
export var productsManageSelector=createFeatureSelector<Array<Products>>("productsManage")
//featureName : productsApi
export var productsApiSelector=createFeatureSelector<Array<Products>>("productsApi")

