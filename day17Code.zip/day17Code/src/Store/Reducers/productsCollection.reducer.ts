import { createReducer, on } from "@ngrx/store";
import { Products } from "src/app/Products";
import { ProductsApiActions } from "../Actions/products.actions";

export var initialState:Array<Products>=[];
// export var productsCollectionReducer=createReducer(initialState,
//     on(ProductsApiActions.storeProductsList,(state,{productsArr})=>{
//         var newState=[...productsArr];
//         return newState;
//     })
// )
