import { createReducer, on } from "@ngrx/store";
import { Products } from "src/app/Products";
import { ProductsActions, ProductsApiActions } from "../Actions/products.actions";

export var initialState:Array<Products>=[];
export var productsChangeReducer=createReducer(initialState,
    on(ProductsApiActions.storeProductsList,(state,{productsArr})=>{
        var newState=[...productsArr];
        return newState;
    }),
    on(ProductsActions.addProduct,(state,{newProduct})=>{
        var newState=[...state];
        newState.push(newProduct);
        console.log("Data in the store in addProducts action",newState);
        return newState;
    }),
    on(ProductsActions.editProduct,(state,{productToBeEdited})=>{
        var newState=[...state];
        var pos=newState.findIndex(item => item.productId == productToBeEdited.productId);
        if(pos >=0)
        {
            newState.splice(pos,1,productToBeEdited);
        }
        return newState;
    }),
    on(ProductsActions.deleteProduct,(state,{productId})=>{
        var newState=[...state];
        var pos=newState.findIndex(item => item.productId == productId);
        if(pos>=0)
        {
            newState.splice(pos,1);
        }
        
        return newState;

    })

)