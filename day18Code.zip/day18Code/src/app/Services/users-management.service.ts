import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class UsersManagementService {
  emailId:string;
  password:string;
  isloggedIn:Subject<boolean>;
  currentStatusOfLogIn:boolean;
  constructor() { 
    this.emailId="";
    this.password="";
    this.isloggedIn=new Subject<boolean>();
    this.isloggedIn.next(false);
    this.currentStatusOfLogIn=false;
    // this.isloggedIn.subscribe((value)=>{
    //   this.currentStatusOfLogIn=value;
    // })
  }
  // getLoginStatus():boolean
  // {
  //   //return this.isloggedIn;
  // }
  setLoggedIn():void
  {
    this.isloggedIn.next(true);
    this.currentStatusOfLogIn=true;
  }
  setLoggedOff():void
  {
    this.isloggedIn.next(false);
    this.currentStatusOfLogIn=false;
  }
}
