import { Component } from '@angular/core';
import { Products } from '../Products';
import { ProductsManagementService } from '../Services/products-management.service';

@Component({
  selector: 'app-product-manage',
  templateUrl: './product-manage.component.html',
  styleUrls: ['./product-manage.component.css']
})
export class ProductManageComponent {
productsArr:Array<Products>;
showEditProductPrice:boolean;
productToBeEdited:Products|null;
constructor(private pms:ProductsManagementService)
{
  this.showEditProductPrice=false;
  this.productToBeEdited=null;
  this.productsArr=pms.getProductsArr();// reference
  // change the productsArr -- will affect the array in the service as well  -- YES
}
editProductPriceEventHandler(productTobeEdited:Products)
{
  // mount the editPriceComponent
  this.showEditProductPrice=true;
  // send data to the child 
  this.productToBeEdited=productTobeEdited;
}
onConfirmPriceEventHandler(editedProduct:Products)
{
  var pos=this.productsArr.findIndex(item => item.productId== editedProduct.productId);
  this.productsArr[pos].price=editedProduct.price;
}
editProductEventHandler(productToBeEdited:Products)
{

}
}
