import { DistancePipe } from './distance.pipe';

describe('DistancePipe', () => {
  it('create an instance', () => {
    const pipe = new DistancePipe();
    expect(pipe).toBeTruthy();
  });
});
