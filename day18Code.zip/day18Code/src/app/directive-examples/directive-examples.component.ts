import { Component } from '@angular/core';

@Component({
  selector: 'app-directive-examples',
  templateUrl: './directive-examples.component.html',
  styleUrls: ['./directive-examples.component.css']
})
export class DirectiveExamplesComponent {
  h2Border:string;
  h3Border:string;
  h3BackgroundColor:string;
  insightsText:string;

  constructor()
  {
    this.h2Border="5px double red";
    this.h3Border="5px dashed brown"
    this.h3BackgroundColor="beige";
    this.insightsText="Understand and monitor your Business Scores & Ratings to help position yourself for future opportunities."
  }

}
