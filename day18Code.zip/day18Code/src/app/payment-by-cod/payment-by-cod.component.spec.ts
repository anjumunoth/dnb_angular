import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByCODComponent } from './payment-by-cod.component';

describe('PaymentByCODComponent', () => {
  let component: PaymentByCODComponent;
  let fixture: ComponentFixture<PaymentByCODComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PaymentByCODComponent]
    });
    fixture = TestBed.createComponent(PaymentByCODComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
