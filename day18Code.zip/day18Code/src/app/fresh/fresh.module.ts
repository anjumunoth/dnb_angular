import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FreshRoutingModule } from './fresh-routing.module';
import { FreshComponent } from './fresh.component';
import { GroceriesComponent } from './groceries/groceries.component';
import { FruitsComponent } from './fruits/fruits.component';
import { VegetablesComponent } from './vegetables/vegetables.component';


@NgModule({
  declarations: [
    FreshComponent,
    GroceriesComponent,
    FruitsComponent,
    VegetablesComponent
  ],
  imports: [
    CommonModule,
    FreshRoutingModule
  ]
})
export class FreshModule { }
