import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangedetectionExampleComponent } from './changedetection-example.component';

describe('ChangedetectionExampleComponent', () => {
  let component: ChangedetectionExampleComponent;
  let fixture: ComponentFixture<ChangedetectionExampleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ChangedetectionExampleComponent]
    });
    fixture = TestBed.createComponent(ChangedetectionExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
