function myFunc(ctr)
{
    return (
        function innerFunc()
        {
            ctr++;
            console.log(ctr);
        }
    );
}

var result=myFunc(100);//Console: ; Data type of result = function
result();// 101

Closure function : Whenever a function returns another function and the inner func should access the outer function variables
-- In a closure function, the outer variable never loses its scope or its memory is freezed

result();//102

result();//103
myFunc(1000)();//1001


var emp={empId:101,empName:"sara",salary:879};
var emp2=emp;// reference
emp2.salary=1000;
console.log(emp);//{empId:101,empName:"sara",salary:1000};
console.log(emp2);//{empId:101,empName:"sara",salary:1000};

var empArr;//Array of objects
var empArr2=empArr;//reference 

function myFunc5(num1)
{
    setTimeout(()=>{
        if(num1%2 ==0)
        {
            return "even";
        }
        else
        {
            return "odd";
        }
    },1000);

}

var result=myFunc5(100);
console.log(result);//undefined
//Promises

// create a promise
function myFunc6(num1)
{
var myPromise =new Promise((resolve,reject)=>{
    setTimeout(()=>{
        if(num1%2 ==0)
            {
                resolve("even");
            }
            else
            {
                reject("odd");
            }
    },1000)
    
})
return myPromise;
}

myFunc6(101)
.then((data)=>{console.log(data)})
.catch((err)=>{console.log(err)})




