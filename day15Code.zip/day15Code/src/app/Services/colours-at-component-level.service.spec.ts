import { TestBed } from '@angular/core/testing';

import { ColoursAtComponentLevelService } from './colours-at-component-level.service';

describe('ColoursAtComponentLevelService', () => {
  let service: ColoursAtComponentLevelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ColoursAtComponentLevelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
