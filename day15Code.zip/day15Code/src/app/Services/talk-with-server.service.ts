import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TalkWithServerService {
  serverUrl:string;
  constructor(private httpClient:HttpClient) {
    this.serverUrl="";
   }

   getAllUsersFromJsonPlaceHolder()
   {
    // get request
      this.serverUrl="https://jsonplaceholder.typicode.com/users"
      return (
        this.httpClient.get(this.serverUrl)
        .pipe(
          catchError(this.handleError)
        )
    )

   }
   private handleError(error:HttpErrorResponse)
   {
    console.log("Error ",error);
    // return an observable or throw an error
    return throwError(()=>{
      new Error("Error occured. Pls try again");
    })

   }
}
