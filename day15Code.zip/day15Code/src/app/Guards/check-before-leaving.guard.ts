import { CanDeactivateFn } from '@angular/router';

export const checkBeforeLeavingGuard: CanDeactivateFn<unknown> =
  (component:any, currentRoute, currentState, nextState) => {
    // componenet -- current component on which the guard is implemented
    // currentRoute -- snapshot of the current route I am in
    // currentState -- snapshot of the current Router state
    // nextState -- snapshot of the route where I am navigating
    console.log("Component details",component)
    console.log("Current Route",currentRoute)
    console.log("Current State",currentState)
    console.log("Next state",nextState)
    //check if there are unsaved changes
    
     if (component?.['unsavedChanges']) {
        var result=confirm("Are u sure u want to leave the page");
        return result;

      }
    
    return true;

    
  };
