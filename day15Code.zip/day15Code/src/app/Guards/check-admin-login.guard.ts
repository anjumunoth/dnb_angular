import { CanActivateFn } from '@angular/router';
import { inject } from '@angular/core';
import { UsersManagementService } from '../Services/users-management.service';

export const checkAdminLoginGuard: CanActivateFn = (route, state) => {
  var userService =inject(UsersManagementService);

  var emailId=userService.emailId;
  if(emailId.indexOf("admin") >=0)
  {
    return true;// allowing the navigation
  }
  return false;// disallowing the navigation
};
