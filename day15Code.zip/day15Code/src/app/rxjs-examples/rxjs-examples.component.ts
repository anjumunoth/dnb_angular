import { Component } from '@angular/core';
import { catchError, filter, find, from, interval, map, mergeMap, Observable, of, range, switchMap, take } from 'rxjs';

@Component({
  selector: 'app-rxjs-examples',
  templateUrl: './rxjs-examples.component.html',
  styleUrls: ['./rxjs-examples.component.css']
})
export class RxjsExamplesComponent {
  dataArr: number[];
  constructor() {
    this.dataArr = [];
    // data -- should it be of same type -- Not necessary
    // send data -- synchronously or async
    // create an Observable to emit the various values
    var myObservable = new Observable((subscriber) => {
      subscriber.next(100);
      subscriber.next(200);
      subscriber.next(300);
      // subscriber.error("Demo error"); will abrutply stop here

      setTimeout(() => {
        subscriber.next(400);
        subscriber.complete();// no more data is there to be sent; stream is closed
        subscriber.error("Demo error")

        subscriber.next(600);// ignore 600; 
      }, 5000);
      subscriber.next(500);


    });

    // open the tap ; get the water stream; subscribe to the observable
    // observer -- set of callback functions

    var mySubscription = myObservable.subscribe(
      {
        next: (value) => {


          console.log("Subscription 1:", value);
        },
        complete: () => { console.log("Subscription 1:data stream is over") },
        error: (err) => { console.log("Subscription 1:Error", err) }


      });
    // can there be multiple subscriptions: YES
    var mySubscription2 = myObservable.subscribe(
      {
        next: (value: any) => {
          console.log("Subscription 2:", value);
          this.dataArr.push(parseInt(value.toString()));
        },
        complete: () => { console.log("Subscription 2:data stream is over") },
        error: (err) => { console.log("Subscription 2:Error", err) }


      });
    // Should all subsciptions handle the data in the same manner
    var mySubscription3 = myObservable.subscribe(
      {
        next: (value: any) => { console.log("Subscription 3:", (value * value)); },
        complete: () => { console.log("Subscription 3:data stream is over") },
        error: (err) => { console.log("Subscription 3:Error", err) }


      });
    // unsubscription
    //mySubscription.unsubscribe();// closing the tap; ngOnDestroy

    // Examples of operators
    var myObservable2 = from([1, 2, 3, 4, 5]);
    myObservable2.subscribe((value) => {
      console.log("MyObservable 2 data ", value);// corresponding to the next method
    });

    var myObservable3 = of("red", "green", "blue");
    myObservable3.subscribe((value) => {
      console.log("MyObservable 3 data ", value);
    })

    // var myObservable4=interval(100);
    // myObservable4.subscribe((value)=>{
    //   console.log("MyObservable 4 data ",value);
    // })

    //Pipes
    var myObservable4 = interval(100).pipe(take(10));
    myObservable4.subscribe((value) => {
      console.log("MyObservable 4 data ", value);
    })


    var myObservable5 = from([1, 2, 3, 4, 5]).pipe(map(item => item * item));
    myObservable5.subscribe((value) => {
      console.log("MyObservable 5 data ", value);// corresponding to the next method
    });

    var myObservable6 = from([10, 20, 30, 40, 50]).pipe(find(item => item > 30));
    myObservable6.subscribe((value) => {
      console.log("MyObservable 6 data ", value);// 40;emit only the first value which matches the predicate function
    });

    var myObservable7 = from([10, 20, 30, 40, 50]).pipe(filter(item => item > 30));
    myObservable7.subscribe((value) => {
      console.log("MyObservable 7 data ", value);// 40;50;emit all the  values which matches the predicate function
    });


    var myObservable8 = from(["red", "green", "blue"]).pipe(switchMap((value) => range(1, value.length)
    ))
    myObservable8.subscribe((value) => {
      console.log("MyObservable 8 data ", value);// 

    });
    var arrNames = ["sara", "jack", "gita"];
    var lastNames = ["mehta", "singh", "g"];
    var myObservable9 = from(arrNames).pipe(mergeMap((value) =>
      from(lastNames).pipe(map(item => item + value))
    ));
    myObservable9.subscribe((value) => {
      console.log("MyObservable 9 data ", value);// 
    });

    // Error operators:
    var arr1=["red","green",{empId:101},"cyan"];
    var myObservable10=new Observable((subscriber)=>{
      for(let i=0;i<arr1.length;i++)
      {
        subscriber.next(arr1[i]);
      }
      
    })

    myObservable10.subscribe((value:any)=>{
      //console.log("MyObservable10 : ",value.toUpperCase());
      of(value).pipe(
        map(item=> item.toUpperCase()),
        catchError((err)=>of(value))
      ).subscribe(value=>console.log("MyObservable10 : ",value));// emits "RED","GREEN",{empId:101},"CYAN"

    })

    // retry
    


  }
}

