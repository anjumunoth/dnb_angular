import { booleanAttribute, Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit
{
  // data from the parent
  @Input({
    transform: booleanAttribute
  }) showBorder:boolean;
  @Input() incValue:number;
  @Input() ctr:number;
  @Input({
    transform:(value:any)=>{
      return ([...(
          value.filter((emp:any)=>{
            return (emp.empName.indexOf("r") >=0);
          })
      )
    ]);
      
    }
  })employeeArr:any;
  @Input({required:true}) myCompanyName:string;
  @Input({
    required:true,
    alias:"emp",
    transform:(value:any)=>{
      
      return {...value};
    }  
   }) employeeDetails :any;
  constructor()
  {
    this.showBorder=false;
    this.incValue=0;
    this.ctr=0;
    this.myCompanyName="dan and bradstreet";
    this.employeeDetails=null;
    this.employeeArr=[];
    
  }
  ngOnInit(): void {
    console.log(`Company Name : ${this.myCompanyName}` );// dnb 
    console.log("employee arr",this.employeeArr)
    //this.emp={...this.emp};// why are u doing this
    // filter out the elements which has r in it
    //this.employeeArr=this.employeeArr.filter((emp:any)=> emp.empName.indexOf("r") >=0);
   
  }
  changeCompanyNameEventHandler()
  {
    this.myCompanyName="dan and bradstreet";
    this.employeeDetails.salary=100;
  }

}
// <input type="button" value="Confirm" disabled />
// presence of the attribute is equivlaent to disabled=true
// shortcut notation



