var emp1={empId:101,empName:"sara",salary:5678};
var emp2=emp1;// creating a reference
emp2.salary=0;
console.log(emp1);//{empId:101,empName:"sara",salary:0};
console.log(emp2);//{empId:101,empName:"sara",salary:0};

// In ES6 -- spread opeartor -- create a new object by spreading the contents of the given objcet
var emp3={empId:101,empName:"sara",salary:5678};
var emp4={...emp1};// create a copy
emp4.salary=0;
console.log(emp3);//{empId:101,empName:"sara",salary:5678};
console.log(emp4);//{empId:101,empName:"sara",salary:0};


var emp5={...emp1,salary:77};// create a copy
console.log(emp5);//{empId:101,empName:"sara",salary:77};

var emp6={salary:77,...emp1};// create a copy
console.log(emp6);//{empId:101,empName:"sara",salary:5678};

var emp1={empName:"sara",salary:5678,address:{city:"chennai",state:"TN"}};
var emp7={...emp1};// copy
emp7.address.city="BLR";
emp7.empName="jack"
console.log(emp1);//{empName:"sara",salary:5678,address:{city:"BLR",state:"TN"}};
console.log(emp7);//{empName:"jack",salary:5678,address:{city:"BLR",state:"TN"}};




