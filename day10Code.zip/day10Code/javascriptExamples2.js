function myFunc(ctr)
{
    return (
        function innerFunc()
        {
            ctr++;
            console.log(ctr);
        }
    );
}

var result=myFunc(100);//Console: ; Data type of result = function
result();// 101

Closure function : Whenever a function returns another function and the inner func should access the outer function variables
-- In a closure function, the outer variable never loses its scope or its memory is freezed

result();//102

result();//103
myFunc(1000)();//1001
