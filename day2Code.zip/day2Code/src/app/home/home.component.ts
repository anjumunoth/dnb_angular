import { Component } from '@angular/core';
import { Products } from '../Products';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  productsArr:Array<Products>  ;
  colours:string[];
  constructor()
  {
    this.productsArr=[
      new Products(101,"Iphone 15 max pro",12345,12,"../assets/iphone15ProMax.jpg","Apple Iphone 15 pro max 256gb white colour"),
      new Products(101,"Iphone 15 max pro",12345,12,"../assets/iphone15ProMax.jpg","Apple Iphone 15 pro max 256gb white colour"),
      new Products(101,"Iphone 15 max pro",12345,12,"../assets/iphone15ProMax.jpg","Apple Iphone 15 pro max 256gb white colour"),
      new Products(101,"Iphone 15 max pro",12345,12,"../assets/iphone15ProMax.jpg","Apple Iphone 15 pro max 256gb white colour"),
      new Products(101,"Iphone 15 max pro",12345,12,"../assets/iphone15ProMax.jpg","Apple Iphone 15 pro max 256gb white colour"),
    ];
    this.colours=["red","green","blue","orange","violet"]
  }
}
