import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortArr'
})
export class SortArrPipe implements PipeTransform {

  transform(arrToBeSorted: any,sortField:string,sortOrder:string): unknown {
    return null;
  }

}
