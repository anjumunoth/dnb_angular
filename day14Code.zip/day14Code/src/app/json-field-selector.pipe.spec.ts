import { JsonFieldSelectorPipe } from './json-field-selector.pipe';

describe('JsonFieldSelectorPipe', () => {
  it('create an instance', () => {
    const pipe = new JsonFieldSelectorPipe();
    expect(pipe).toBeTruthy();
  });
});
