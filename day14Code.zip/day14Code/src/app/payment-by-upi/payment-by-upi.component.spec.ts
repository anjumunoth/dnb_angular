import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByUpiComponent } from './payment-by-upi.component';

describe('PaymentByUpiComponent', () => {
  let component: PaymentByUpiComponent;
  let fixture: ComponentFixture<PaymentByUpiComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PaymentByUpiComponent]
    });
    fixture = TestBed.createComponent(PaymentByUpiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
