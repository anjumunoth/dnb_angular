import { inject } from '@angular/core';
import { CanActivateFn, createUrlTreeFromSnapshot, UrlTree } from '@angular/router';
import { UsersManagementService } from '../Services/users-management.service';

export const checkLoggedInGuard: CanActivateFn = (route, state) => {
  console.log("Route",route);
  console.log("state",state);
  var userService =inject(UsersManagementService);
  var loggedInStatus:boolean=false;
    //   userService.isloggedIn.subscribe((value)=>{
    //     console.log("New value of logged in in the guard",value)
    //     loggedInStatus=value;
    //   })
    // alert("Logged in status"+loggedInStatus);
    loggedInStatus=userService.currentStatusOfLogIn;
    // route -- details of the route to which we are navigating
    // state -- router state details
    var loginPath:UrlTree=createUrlTreeFromSnapshot(route,["/login"]);
    return loggedInStatus?true:loginPath;
};
