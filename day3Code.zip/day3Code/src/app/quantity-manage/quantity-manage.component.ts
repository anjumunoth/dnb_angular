import { Component } from '@angular/core';

@Component({
  selector: 'app-quantity-manage',
  templateUrl: './quantity-manage.component.html',
  styleUrls: ['./quantity-manage.component.css']
})
export class QuantityManageComponent {
  selectedQuantity:number;
  maxQuantity:number;
  constructor()
  {
    this.selectedQuantity=1;
    this.maxQuantity=10;
  }
}
