import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';//inbuilt module

import { AppRoutingModule } from './app-routing.module';//custom module
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { QuantityManageComponent } from './quantity-manage/quantity-manage.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { TemplateExamplesComponent } from './template-examples/template-examples.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ProductManageComponent,
    QuantityManageComponent,
    AddToCartComponent,
    TemplateExamplesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
